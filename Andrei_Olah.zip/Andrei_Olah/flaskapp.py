from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask import request, redirect, url_for

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    age = db.Column(db.Integer)

    def __repr__(self):
        return f"User: {self.username}\nEmail: {self.email}"


class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey(User.id))
    posted = db.Column(db.DateTime, nullable=False)
    title = db.Column(db.String(120), nullable=False)
    body = db.Column(db.String(500), nullable=False)
    view_counter = db.Column(db.Integer, default=0)

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.String(500), nullable=True)
    reviewed_at = db.Column(db.DateTime, nullable=False, default=db.func.now())

    post = db.relationship('Post', backref='reviews', lazy=True)
    user = db.relationship('User', backref='reviews', lazy=True)

    def __repr__(self):
        return f"<Review {self.id} - Post {self.post_id}, User {self.user_id}>"



@app.route('/')
def display_content(content=None):
    return render_template('base.html', content=content)


@app.route('/user/profile/<int:user_id>')
def display_user_profile(user_id):
    user = User.query.filter_by(id=user_id).first()
    return render_template('user_profile.html', user=user)


@app.route('/users')
def display_all_users():
    users = User.query.all()
    return render_template('users.html', users=users)


@app.route('/posts')
def display_all_posts():
    posts = Post.query.all()
    return render_template('posts.html', posts=posts)


@app.route('/post/<int:post_id>', methods=['GET', 'POST'])
def display_post(post_id):
    found_post = Post.query.filter_by(id=post_id).first()

    if not found_post:
        return render_template('post_not_found.html')

    if request.method == 'POST':
        rating = int(request.form['rating'])
        comment = request.form['comment']
        user_id = int(request.form['user_id'])

        new_review = Review(post_id=post_id, user_id=user_id, rating=rating, comment=comment)
        db.session.add(new_review)
        db.session.commit()

        return redirect(url_for('display_post', post_id=post_id))

    found_post.view_counter += 1
    db.session.commit()

    return render_template('post.html', post=found_post)
