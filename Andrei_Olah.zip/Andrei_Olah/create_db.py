from datetime import datetime

from flaskapp import app, db, User, Post, Review

with app.app_context():
    db.create_all()

    # Populate database with some entries
    admin = User(username='admin', email='admin@example.com', age=42)
    regular_user = User(username='user', email='user@example.com', age=20)

    post1 = Post(user_id=1,
                 posted=datetime.strptime("5 November 2021", "%d %B %Y"),
                 title="Hello World!",
                 body="This is the first post on this blog.",
                 view_counter=0)


    post2 = Post(user_id=1,
                 posted=datetime.strptime("17 November 2021", "%d %B %Y"),
                 title="Post Number two",
                 body="This is the second post on this blog.",
                 view_counter=0)

    post3 = Post(user_id=2,
                 posted=datetime.utcnow(),
                 title="Post number three",
                 body="This is the third post on this blog.",
                 view_counter=0)

    db.session.add(admin)
    db.session.add(regular_user)
    db.session.add(post1)
    db.session.add(post2)
    db.session.add(post3)

    # Reviews
    review1 = Review(
        post_id=1,
        user_id=2,
        rating=5,
        comment="Amazing first post! Very inspiring.",
        reviewed_at=datetime.utcnow()
    )

    review2 = Review(
        post_id=1,
        user_id=1,
        rating=4,
        comment="It’s decent, but I could have done better.",
        reviewed_at=datetime.utcnow()
    )

    review3 = Review(
        post_id=2,
        user_id=2,
        rating=3,
        comment="This post is okay, but not as engaging as the first one.",
        reviewed_at=datetime.utcnow()
    )

    review4 = Review(
        post_id=3,
        user_id=1,
        rating=5,
        comment="Great content! Keep up the good work!",
        reviewed_at=datetime.utcnow()
    )

    review5 = Review(
        post_id=3,
        user_id=2,
        rating=4,
        comment="Thanks for sharing! Really enjoyed this post.",
        reviewed_at=datetime.utcnow()
    )

    db.session.add(review1)
    db.session.add(review2)
    db.session.add(review3)
    db.session.add(review4)
    db.session.add(review5)

    db.session.commit()

